# Import Python's random module
init python:
    import random

# Disable scroll forward (mouse wheel down) and scroll backward (mouse wheel up)
$ config.keymap['rollback'] = []
$ config.keymap['rollforward'] = []

screen moral_display(moral, points):
    # Background for the overlay
    frame:
        style "moral_frame"
        align (0.5, 0.5)
        padding (50, 50)
        
        vbox:
            spacing 20
            xalign 0.5

            # Display the moral title
            text "[moral]" style "moral_title"

            # Display the points as a bulleted list
            for point in points:
                text "• [point]" style "moral_point"

# Styles for customization
style moral_frame:
    background "#000000a4"  # Semi-transparent black background
    xpadding 20
    ypadding 20
    xalign 0.5
    yalign 0.5

style moral_title:
    size 36
    color "#FFFFFF"
    bold True
    text_align 0.5  # Center-align the text

style moral_point:
    size 24
    color "#EEEEEE"
    text_align 0.0  # Left-align the bullet points

# Declare the characters
define b = Character("Bhindi",color="#ff5733")
define m = Character("Madhuri",color="#f8d00b")
define k = Character("Kapti Seth",color="#CC338B")
default registration_checked = False
default hallmark_checked = False
default huid_verified = False
default hallmark_is_fake = False
default proper_bill = False
# Start the game
label start:

    # Scene 1: Bhindi's Home
    scene bg home
    play music "scene_1_bgm.mp3" volume 0.15
    #new addition dated 16/12/24
    show madhuri neutral
    m "Dear, do you remember what day is it?"
    show madhuri neutral at left with move
    show bhindi neutral at right
    b "It's 29th November, why?"
    show madhuri angry
    m "Its our Anniversary today. You forgot right?"   
    show bhindi confused
    b "Ofcourse not, I remember, I am even planning to buy you new earrings."
    show madhuri smile
    m "Oh really! {w} How sweet of you!"
    show bhindi smile
    b "Yes, dear. I’ll go to Kapti Seth’s shop today and get you a new pair of earrings."
    
    m "Great! But don’t forget to check his registration on manakonline website."

    menu:
        "Yeah, I will check it for sure.":
            $ registration_checked = True
            b "Yeah, I will check it for sure."
            m "Good! Always stay cautious."
            scene bg home_blur
            show verify registration
            "(Bhindi uses manakonline website and verifies Kapti Seth’s registration.)"
            show verify registration2
            "(Bhindi uses manakonline website and verifies Kapti Seth’s registration.)"
        "It’s not needed. He’s the most famous jeweller in the city.":
            stop music fadeout 3.0
            $ registration_checked = False
            hide madhuri
            show bhindi neutral
            b "(To Himself) It’s not needed. He’s the most famous jeweller in the city."

    stop music fadeout 2.0

    # Scene 2: Kapti Seth's Shop
    scene bg shop with fade
    play music "scene_2_bgm.mp3" volume 0.2
    show kapti namaste
    k "Namaste, Bhaisaab! What would you like to buy today?"
    show kapti neutral at right with move
    show bhindi smile at left
    b "I’m looking for a pair of earrings for my wife."
    k "Wonderful! How much is your budget?"
    show bhindi neutral
    b "Around ₹45,000–₹50,000."
    k "Perfect. Let me show you some options."
    k "(Presents an earring box.)"
    
    scene bg shop_blur
    show white_earrings at top
    "Bhindi looks at these earrings and picks them up."
    scene bg shop
    show bhindi earrings neutral at left
    b "These earrings look nice. I’ll take this pair."
    show kapti neutral at right
    k "Excellent choice! The gold weighs 5.980 grams with 916 purity." #Edited 16/12/24

    menu:
        "Can I get a magnifying glass to check the hallmark?":
            $ hallmark_checked = True
            b "Can I get a magnifying glass to check the hallmark?"
            k "Of course, bhaisaab."
            "Bhindi examines the hallmark and finds: BIS Mark, Purity (916), and 6-digit HUID."
            show bhindi earrings happy
            b "The hallmark is present and looks authentic."
        "No need for a magnifying glass. It’s fine; I trust you.":
            $ hallmark_checked = False
            b "No need for a magnifying glass. It’s fine; I trust you."
            k "As you wish!"

    # Scene 3: Checking HUID Details
    if hallmark_checked:
        show bhindi earrings neutral
        b "(To himself) Should I verify the HUID on the BIS CARE app?"

        menu:
            "Yes, it’s important to check.":
                $ huid_verified = True
                show bhindi earrings neutral
                b "(To himself) Yes, it’s important to check."
                scene bg shop_blur
                show verify huid
                "Bhindi uses the BIS CARE app to verify the HUID."
                # Randomized outcome
                $ hallmark_is_fake = random.choice([True, False])

                if hallmark_is_fake:
                    scene bg shop
                    show bhindi earrings distressed
                    b "(Realizes the hallmark is fake!) This hallmark doesn’t seem right."
                    menu:
                        "Confront Kapti Seth.":
                            stop music fadeout 1.0
                            play music "confront.mp3" volume 0.2
                            b "Sethji, this doesn’t match! The weight and jeweller details are wrong."
                            show bhindi earrings distressed at left with move
                            show kapti sad at right
                            k "Oh, that must be a mistake. Let me check again. (Avoids the issue.)"
                            b "I’m not buying this. I’ll report this to BIS. (Leaves the shop.)"
                            stop music fadeout 1.0
                        "Leave quietly":
                            b "(Leaves the shop.)"
                    jump Consequences
                else:
                    scene bg shop
                    show bhindi earrings happy
                    b "Everything matches perfectly. These are authentic earrings!"
                    show bhindi earrings happy at left with move
                    show kapti neutral at right
                    k "See, I told you we only sell authentic items."
                # Add further checks and subchoices here
            "No, this much checking is enough.":
                $ huid_verified = False
                b "No, this much checking is enough."

    # Scene 4: Asking for a Proper Bill Edited-16/12/24
    scene bg shop with fade
    show kapti neutral at right
    show bhindi smile at left
    k "Here you go, bhaisaab. If you take a handwritten bill you wont need to pay GST."
    b "How much would I need to pay then?"
    k "With a handwritten bill Rs 46835.4, but with proper bill Rs 48328.1"

    menu:
        "Take a proper bill":
            $ proper_bill = True
            b "Can I have a proper printed bill, please?"
            show kapti namaste at right
            k "Sure, here you go! Your earrings and a proper bill."
            scene bg shop_blur
            show proper bill at top
            "Bhindi receives the earrings and a proper bill."

        "A handwritten bill is fine":
            $ proper_bill = False
            b "A handwritten bill is fine."
            show kapti namaste at right
            k "Thank you for trusting me! Here are your earrings and a handwritten bill."
            scene bg shop_blur
            show handwritten bill at top
            "Bhindi receives the earrings and a handwritten bill."
            

    scene bg shop 
    show kapti neutral at right
    b "(Leaves the shop)"
    stop music fadeout 1.0

# Extra scene
    if not(hallmark_checked) or not(huid_verified) or not(proper_bill):
        scene bg shop with fade
        play sound "corrupt kapti.mp3" volume 1.5
        show kapti kapat
        k "(To himself) What a fool."


label Consequences:
    # Scene 5: At Home – Consequences
    scene bg home with fade
    if registration_checked and hallmark_checked and huid_verified and not(hallmark_is_fake) and proper_bill:
        play music "happy music.mp3" volume 0.2
        show bhindi earrings happy at right
        show madhuri smile at left
        m "Wow, these earrings are perfect! And you checked everything so thoroughly.{w} I’m so proud of you!"
        b "(Feels confident about his purchase.)"
        m "(Feels delighted and is proud of her husband.)"
        scene bg home_blur
        $ moral = "Bhindi says when purchasing gold jewellery, always:"
        $ points = [
            "Verify the jeweller’s registration on the BIS Care app.",
            "Check the hallmark for BIS Mark, purity, and HUID.",
            "Use the BIS Care app to validate the HUID details like jeweller registration, ornament name, and ornament weight.",
            "Insist on a proper printed bill for authenticity and legal recourse."
        ]
        # Show the screen
        show screen moral_display(moral, points)
        # Wait for the player to click
        "Ignoring these steps can lead to significant financial and emotional loss."
        stop music fadeout 1.0
    
    elif not (registration_checked) and hallmark_checked and huid_verified and not(hallmark_is_fake) and proper_bill:
        play music "scene_1_bgm.mp3" volume 0.15
        show bhindi earrings happy at right
        b "Here are your earrings! My dear."
        show madhuri neutral at left
        m "Did you check everything? The hallmark, HUID, and the bill?"
        show bhindi earrings neutral
        b "I did not check his registration. Rest all is okay."
        show madhuri distressed 
        m "You shouldn't be so careless. This would have caused us a big damage. Thankfully we didnt get fooled."
        b "I would not make such a mistake again."
        stop music fadeout 1.0
        scene bg home_blur
        play music "sad music.mp3" volume 0.9
        $ moral = "Dont be like Bhindi, when purchasing gold jewellery, always:"
        $ points = [
            "Verify the jeweller’s registration on the BIS Care app."
        ]
        # Show the screen
        show screen moral_display(moral, points)
        # Wait for the player to click
        "Ignoring these small important steps can make you a fraud victim."
        stop music fadeout 1.0
        
    elif not(registration_checked) and hallmark_checked and huid_verified and not(hallmark_is_fake) and not (proper_bill):
        play music "scene_1_bgm.mp3" volume 0.15
        show bhindi earrings happy at right
        b "Here are your earrings! My dear."
        show madhuri neutral at left
        m "Did you check everything? The hallmark, HUID, and the bill?"
        show bhindi earrings neutral
        b "I didnt check the registration and he gave me a handwritten bill. I thought it was okay"
        stop music fadeout 1.0
        play music "sad music.mp3" volume 0.9 fadein 1.0
        show madhuri angry
        m "Dont you know how important it is to have a proper bill. What if Kapti Seth denies this transaction in the future. We'll have no proof.{w} And you didn't even check his registration."
        show madhuri distressed
        show bhindi earrings distressed
        m "(Dissapointed) I expected better from you"
        b "I am sorry. I will keep this in mind in the future."
        scene bg home_blur
        $ moral = "Dont be like Bhindi, when purchasing gold jewellery, always:"
        $ points = [
            "Always check the jeweller’s registration on the BIS Care app.",
            "Don't be like Bhindi! Always ask for a proper bill."
        ]
        # Show the screen
        show screen moral_display(moral, points)
        # Wait for the player to click
        "Ignoring these small important steps can make you a fraud victim."
        stop music fadeout 1.0

    elif registration_checked and hallmark_checked and huid_verified and not(hallmark_is_fake) and not (proper_bill):
        play music "scene_1_bgm.mp3" volume 0.15
        show bhindi earrings happy at right
        b "Here are your earrings! My dear."
        show madhuri neutral at left
        m "Did you check everything? The hallmark, HUID, and the bill?"
        show bhindi earrings neutral
        b "He gave me a handwritten bill. I thought it was okay"
        stop music fadeout 1.0
        play music "sad music.mp3" volume 0.9 fadein 1.0
        show madhuri angry
        m "Dont you know how important it is to have a proper bill. What if Kapti Seth denies this transaction in the future. We'll have no proof."
        show madhuri distressed
        show bhindi earrings distressed
        m "(Dissapointed) I expected better from you"
        b "I am sorry. I will keep this in mind in the future."
        scene bg home_blur
        $ moral = "Dont be like Bhindi, when purchasing gold jewellery, always:"
        $ points = [
            "Always ask for a proper bill."
        ]
        # Show the screen
        show screen moral_display(moral, points)
        # Wait for the player to click
        "Ignoring these small important steps can make you a fraud victim."
        stop music fadeout 1.0

    elif huid_verified and hallmark_is_fake:
        play music "scene_1_bgm.mp3" volume 0.15
        show madhuri neutral
        m "Where are my earrings, dear?"
        show madhuri neutral at left with move
        show bhindi confused at right
        b "I visited the shop but didn't buy them."
        m "But why?"
        b "Kapti Seth is a fake. He tried to sell me fake jewellery."
        show madhuri distressed
        m "Oh God!{w} Did you report him to the BIS?"
        menu:
            "Yes, I am going to report him to the BIS.":
                show bhindi smile
                b "Yes I am going to report him to the BIS."
                scene bg home_blur
                show lodge complaint
                b "(Uses the BIS CARE app to report the jeweller.)"
                stop music fadeout 1.0
                scene bg shop with fade
                play music "kapti reported.mp3" volume 0.2
                show kapti sad
                "Kapti Seth's registration is cancelled and he can no more fool innocent people."
                stop music fadeout 1.0

                scene bg home_blur with fade
                play music "happy music.mp3" volume 0.2
                $ moral = "Be like Bhindi:"
                $ points = [
                    "BIS Says you should always report such fraudsters to the authority using BIS CARE App."
                ]
                # Show the screen
                show screen moral_display(moral, points)
                "Ignoring these small important steps can make you a fraud victim."
                stop music fadeout 1.0

            "No, I don't want more problems.":
                stop music fadeout 1.0
                show bhindi neutral
                b "No, I don't want more problems."
                scene bg shop with fade
                play sound "corrupt kapti.mp3" volume 1.5
                show kapti kapat
                "Kapti seth isn't reported and continues to sell fake jewelry to unsuspecting people who do not verify his jewelry."
                
                scene bg home_blur with fade
                play music "sad music.mp3" volume 0.9
                $ moral = "Dont be like Bhindi:"
                $ points = [
                    "BIS Says you should always report such fraudsters to the authority using BIS CARE App."
                ]
                # Show the screen
                show screen moral_display(moral, points)
                "Ignoring these small important steps can make you a fraud victim."
                stop music fadeout 1.0

    else:
        play music "scene_1_bgm.mp3" volume 0.15
        show bhindi earrings happy at right
        b "Here are your earrings! My dear."
        show madhuri neutral at left
        m "Did you check everything? The hallmark, HUID, and the bill?"
        b "Of course{w}, I trust Kapti Seth."
        m "Let me have a look... (Examines the earrings closely.)"
        stop music fadeout 1.0
        play music "sad music.mp3" volume 0.9 fadein 1.0
        if not (hallmark_checked):
            show madhuri angry
            m "Wait, where’s the proper hallmark?{w} This is a 5-digit HUID, HUID must be of 6 digits{w}, it's obviously fake. This doesn’t even look like 916 gold!"
        elif not (huid_verified):
            scene bg home_blur
            show verify huid
            "(Madhuri uses the BIS CARE app to check the details and discovers discrepancies.)"
            scene bg home
            show madhuri angry at left
            m "Hey! This HUID number doesn’t match the earrings.{w} These might be fake! This doesn’t even look like 916 gold!"
        show bhindi earrings distressed at right
        b "Fake? But Kapti Seth is so famous!"
        show madhuri distressed
        m "Fame doesn’t guarantee honesty. I told you to check the registration and verify everything!"
        if proper_bill:
            stop music fadeout 1.0
            play music "happy music.mp3" volume 0.2
            show bhindi earrings neutral
            b "Thank God, I have a proper bill.  I will complain about this on the BIS CARE app and make sure his registration gets cancelled."
            scene bg home_blur
            show lodge complaint
            "Bhindi reports Kapti Seth on the BIS CARE App."
            stop music fadeout 1.0
            scene bg shop with fade
            play music "kapti reported.mp3" volume 0.2
            show kapti sad
            "Kapti Seth's registration is cancelled and he can no more fool innocent people. Thanks to Bhindi who reported the matter to BIS."
            stop music fadeout 1.0
            scene bg home_blur
            play music "happy music.mp3" volume 0.2
            $ moral = "Dont be like Bhindi, when purchasing gold jewellery, always:"
            $ points = [
                "Verify the jeweller’s registration on the BIS Care app.",
                "Check the hallmark for BIS Mark, purity, and HUID.",
                "Use the BIS Care app to validate the HUID details like jeweller registration, ornament name, and ornament weight.",
            ]
            # Show the screen
            show screen moral_display(moral, points)
            # Wait for the player to click
            "Bhindi was saved from a big fraud because he asked for a proper bill, ignoring these small important steps can make you a fraud victim."
            stop music fadeout 1.0
            
        else:
            b "I will go to his shop tomorrow and fix everything."
            stop music fadeout 1.0
            # Scene 6: Bhindi’s Attempt to Fix the Situation
            play music "confront.mp3" volume 0.2
            scene bg shop with fade
            "The next day, Bhindi goes back to Kapti Seth’s shop."
            show bhindi earrings distressed
            b "Sethji, these earrings don’t seem authentic. The HUID doesn’t match, and the gold doesn’t feel like 916 purity."
            show bhindi earrings distressed at left with move
            play sound "corrupt kapti.mp3" volume 1.5
            show kapti kapat at right
            k "Nonsense! I sell only genuine jewellery. You already paid and took them home. I can’t do anything now."
            b "But I need a proper bill to file a complaint!"
            show bhindi earrings distressed with vpunch
            k "You didn’t ask for one yesterday. I can’t help you now."
            "Bhindi leaves the shop, frustrated and dejected."
            stop music fadeout 1.0

            # 16/12/24 Scene 7: Bhindi goes back home 
            scene bg home with fade
            play music "sad music.mp3" volume 0.9
            show madhuri distressed
            m "What happened, did Kapti Seth replace them?"
            show madhuri distressed at left with move
            show bhindi earrings distressed at right
            b "No he denied it, we cant do anything now."
            m "He conned us and now we are helpless."
            scene bg home_blur
            $ moral = "Dont be like Bhindi, when purchasing gold jewellery, always:"
            $ points = [
                "Verify the jeweller’s registration on the BIS Care app.",
                "Check the hallmark for BIS Mark, purity, and HUID.",
                "Use the BIS Care app to validate the HUID details like jeweller registration, ornament name, and ornament weight.",
                "Insist on a proper printed bill for authenticity and legal recourse."
            ]
            # Show the screen
            show screen moral_display(moral, points)
            # Wait for the player to click
            "Ignoring these steps can lead to significant financial and emotional loss."
            stop music fadeout 1.0
    return
